package cn.mmvtc.shop.utils;

public class DBUtils {
    public static final String DATABASE_NAME="Shopping";
    public static final String DATABASE_TABLE="shop";
    public static final int DATABASE_VERION=1;
    public static final String SHOPPING_ID="id";
    public static final String SHOPPING_TITLE="title";
    public static final String SHOPPING_PRICE="price";
}
